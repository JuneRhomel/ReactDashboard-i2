<?php
include_once('../library.php');
global $rootpath;
session_start();
session_destroy();
header("location: $rootpath");