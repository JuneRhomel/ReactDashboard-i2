<?php
include("footerheader.php");
fHeader();

$id = initObj('id');
$tenant = initSession('tenant');

$api = apiSend('amenity','getlist',ARR_BLANK);
$list = json_decode($api,true);
foreach ($list as $key0=>$val0) {
    if ($val0['id']==$id)
        $val = $val0;
}

$remarks = "";
if (initObj('action')!="") {
    $remarks = "test remarks ".DATETIME;
}
?>
<div class="container">
    <div class="title mt-5 pt-4 pb-3">Reservations</div>
</div>
<form id="frm" name="frm" method="post" enctype="multipart/form-data" action="reservation-save.php">
    <div class="py-3 bg-white">
        <div class="container">
            <div class="mb-2">
                <div class="py-2">Amenity</div>
                <div>
                    <input name="amenity_name" type="text" class="form-control" value="<?=$val['amenity_name']?>" readonly />
                </div>
            </div>
            <div class="mt-0 row">
                <div class="col-6">
                    <div class="mt-2">Start Date/Time</div>
                    <div class="input-group mt-2">
                        <input name="reserved_from" type="datetime-local" class="form-control" value="2022-06-25 13:00" required/>
                    </div>
                </div>
                <div class="col-6">
                    <div class="mt-2">End Date/Time</div>
                    <div class="input-group mt-2">
                        <input name="reserved_to" type="datetime-local" class="form-control" required />
                    </div>
                </div>
            </div>
            <div class="mb-2">
                <div class="py-2">Tenant</div>
                <div>
                    <input type="text" class="form-control" value="<?=$tenant['tenant_name']?>" readonly />
                </div>
            </div>
            <div class="mb-2">
                <div class="py-2">Contact Number</div>
                <div>
                    <input type="text" class="form-control" value="<?=$tenant['mobile']?>" readonly />
                </div>
            </div>
            <div class="mb-2">
                <div class="py-2">Email Address</div>
                <div>
                    <input type="text" class="form-control" value="<?=$tenant['email']?>" readonly />
                </div>
            </div>
            <div class="mb-2">
                <div class="py-2">Remarks</div>
                <div>
                    <div class="form-group">
                        <textarea name="description" class="form-control" rows="3" required><?=$remarks?></textarea>
                    </div>
                </div>
            </div>
            <div class="row mt-3" style="padding: 0 15px">
                <div class="col-6">
                    <button class="btn btn-outline font-16 w-100">Cancel</button>
                </div>
                <div class="col-6 d-block">
                    <button class="btn btn-primary px-3 w-100">Submit</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php
fFooter();
?>