<?php
include("footerheader.php");
fHeader();
global $scriptname;

$type = initObj('type'); // default visitor
if ($type=="") 
    $api = apiSend('visitor','getlist',ARR_BLANK);
else
    $api = apiSend('tenant','getregistrations',ARR_BLANK);
$list = json_decode($api,true);
//vdumpx($list);
?>
<div class="col-12 d-flex align-items-center justify-content-between" style="margin: 80px 0 20px">
    <div class="title">Registration</div>
    <div>
        <a href="<?=($type=="") ? "visitor.php" : "tenant.php" ?>">
            <button class="btn btn-primary btn-lg pb-0"><h6> New </h6></button>
        </a>
    </div>
</div>
<div class="col-12 mb-4">
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist" style="border-bottom:solid 1px transparent">
            <button class="nav-link <?=($type=="") ? "active" : ""?>" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>'"> Visitor </button>
            <button class="nav-link <?=($type!="") ? "active" : ""?>" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>?type=tenant'"> Tenant </button>
        </div>
    </nav>
</div>

<?php if ($type=="") { // visitor ?>  
<div class="col-12 d-flex align-items-center justify-content-between">
    <div class="font-weight-bold mb-2"><h5>Upcoming</h5></div>
</div>
<?php 
$ynExist = false;
foreach ($list as $key=>$val) { 
    if ($val['status']=="Pending") {
        $ynExist = true;
?> 
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div><label class="label-fade">Arrival Date: </label>  <b><u><?=formatDate($val['arrival_date'])?></u></b></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['visitor_name']?></div>
            </div>
        </div>
        <div>
            <div><label class="label-fade mr-2">Identification:</label>  <img src="<?=$val['id_url']?>" class="img-thumbnail"></div>
        </div>
    </div>
</div>
<?php 
    } // if status = pending
} // foreach

if (!$ynExist) {
    echo '
    <div class="bg-white">
        <div class="col-12 mb-3 py-3">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-14">No record found.</div>
            </div>
        </div>
    </div>';
}
?>

<div class="col-12 d-flex align-items-center justify-content-between mt-3">
    <div class="font-weight-bold mb-2"><h5>Past Visitor</h5></div>
</div>
<?php
$ynExist = false;
foreach ($list as $key=>$val) { 
    if ($val['status']!="Pending") {
        $ynExist = true;
?>
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div><label class="label-fade">Arrival Date: </label>  <b><u><?=formatDate($val['arrival_date'])?></u></b></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['visitor_name']?></div>
            </div>
        </div>
        <div>
            <div><label class="label-fade mr-2">Identification:</label>  <img src="<?=$id_url?>" class="img-thumbnail"></div>
        </div>
    </div>
</div>
<?php 
    } // if status = pending
} // foreach

if (!$ynExist) {
    echo '
    <div class="bg-white">
        <div class="col-12 mb-3 py-3">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-14">No record found.</div>
            </div>
        </div>
    </div>';
}
?>

<?php } else { // tenant ?>
<div class="col-12 d-flex align-items-center justify-content-between">
    <div class="font-weight-bold mb-2"><h5>Upcoming</h5></div>
</div>
<?php 
$ynExist = false;
foreach ($list as $key=>$val) { 
    if ($val['status']=="Pending") {
        $ynExist = true;
?> 
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['tenant_name']?></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="row">
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-map-marker-alt circle-inverse"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['location_name']?></label>
                </div>
                <div class="col-6 p-2"></div>
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-envelope circle-inverse" style="padding:8px;"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['email']?></label>
                </div>
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-mobile-alt circle-inverse"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['mobile']?></label>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    } // if status = pending
} // foreach

if (!$ynExist) {
    echo '
    <div class="bg-white">
        <div class="col-12 mb-3 py-3">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-14">No record found.</div>
            </div>
        </div>
    </div>';
}
?>

<div class="col-12 d-flex align-items-center justify-content-between mt-3">
    <div class="font-weight-bold mb-2"><h5>Past Tenant</h5></div>
</div>
<?php
$ynExist = false;
foreach ($list as $key=>$val) { 
    if ($val['status']!="Pending") {
        $ynExist = true;
?>
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['tenant_name']?></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="row">
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-map-marker-alt circle-inverse"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['location_name']?></label>
                </div>
                <div class="col-6 p-2"></div>
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-envelope circle-inverse" style="padding:8px;"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['email']?></label>
                </div>
                <div class="col-6 d-flex align-items-center justify-content-start pl-3">
                    <i class="fa fa-mobile-alt circle-inverse"></i>
                    <label class="ml-3 mt-2 font-14"><?=$val['mobile']?></label>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
    } // if status = pending
} // foreach

if (!$ynExist) {
    echo '
    <div class="bg-white">
        <div class="col-12 mb-3 py-3">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-14">No record found.</div>
            </div>
        </div>
    </div>';
}
?>

<?php } // if type ?>
<div class="mt-5">&nbsp;</div>
<?=fFooter();?>