<?php
include("footerheader.php");
fHeader();

$list = [
  ["id"=>"1", "amenity_name"=>"Swimming Pool", "operating_hours"=>"9:00 am - 12:00 pm", "picture_url"=>"/resources/images/imgPool.png"],
  ["id"=>"2", "amenity_name"=>"Function Room", "operating_hours"=>"9:30 am - 12:00 pm", "picture_url"=>"/resources/images/imgFunctionRoom.png"],
  ["id"=>"3", "amenity_name"=>"Study Room", "operating_hours"=>"10:00 am - 12:00 pm", "picture_url"=>"/resources/images/imgStudyRoom.png"],
  ["id"=>"4", "amenity_name"=>"Outdoor Space", "operating_hours"=>"10:30 am - 12:00 pm", "picture_url"=>"/resources/images/imgOutdoorSpace.png"],
  ["id"=>"5", "amenity_name"=>"Fitness and Wellness Gym", "operating_hours"=>"9:00 am - 12:00 pm", "picture_url"=>"/resources/images/imgGym.png"],
];

$api = apiSend('amenity','getlist',ARR_BLANK);
$list = json_decode($api,true);
?>
<div class="container">
    <div class="title mt-5 pt-4 pb-3"> Reservation </div>
</div>
<div class="py-1">
    <div class="container">
        <div class="row">
            <?php foreach ($list as $key=>$val) { ?>             
            <div class="col-6 mb-3">
                <a href="reservation-detail.php?id=<?=$val['id']?>">
                    <div class="mb-1"><img src="<?=$val['picture_url']?>" class="rounded"></div>
                    <div class="font-14"><?=$val['amenity_name']?></div>
                    <div class="font-10">Opening Hours <b><?=$val['operating_hours']?></b></div>
                </a>
            </div>            
            <?php } ?>
        </div>
    </div>
</div>
<?php
fFooter();
?>