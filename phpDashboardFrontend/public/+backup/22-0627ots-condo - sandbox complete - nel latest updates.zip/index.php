<?php
session_start();
if(isset($_SESSION['tenant']))
{
    header("location: home.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Login</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous" />
        <link rel="stylesheet" href="custom.css?v=<?=time()?>" />
        
    </head>
    <body style="background-color: #f4f4f4; height: 100vh;">
        <!-- nav -->
        <div class="container">
            <div class="subtitle font-22 text-uppercase my-4 pt-5 pb-3 text-center"> TENANT PORTAL </div>
        </div>
        
        <div class="py-3 bg-white">
            <div class="container d-flex justify-content-center">
                <div class="py-4"><h5>LOGIN</h5></div>
            </div>
            <div class="container">
                <form method="post" action="otp.php">
                <div class="mb-2">
                    <div class="mb-2 font-14">Email Address</div>
                    <div>
                        <input type="email" class="form-control" name="email" id="exampleInputEmail1" />
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-6">
                        <button class="btn btn-outline-primary font-16 w-100 d-block" onclicka="location='otp-mobile.php'" name="bymobile">OTP Mobile</button>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-primary d-block w-100" onclicka="location='otp-email.php'" name="byemail">OTP Email</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
        <!-- bottom tabs -->
        <div style="padding-top: 70px;">
            <div class="row m-0 d-flex justify-content-center">
                <div class="col p-0" style="border-radius: 6px">
                    <div class="col-12 d-flex align-items-center">
                        <div class="mx-auto mt-auto">
                            <b style="font-color:#34495E; opacity:60%">P O W E R E D&nbsp;&nbsp;&nbsp;&nbsp;B Y</b>
                        </div>
                    </div>
                    <div class="col-12 d-flex mt-2">
                        <div class="mx-auto mb-auto">
                            <img class="mx-auto" src="resources/images/Inventi_Horizontal-Blue-01.png" alt="" width="100" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    </body>
</html>