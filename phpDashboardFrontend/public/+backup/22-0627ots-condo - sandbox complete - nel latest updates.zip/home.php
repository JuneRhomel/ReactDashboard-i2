<?php
include("footerheader.php");

$news = json_decode(apiSend('news','getlist',[]));
$requests = [
  ["id"=>"1", "module"=>"GATE PASS", "type"=>"Delivery", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", "status"=>"New"],
  ["id"=>"2", "module"=>"SERVICE REQUEST", "type"=>"Maintenance", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", "status"=>"Pending"],
  ["id"=>"3", "module"=>"RESERVATION", "type"=>"Swimming Pool", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", "status"=>"Closed"],
];

$bills = [
  ["id"=>"1", "monthyear"=>"Apr 2022", "refno"=>"24324-0003", "status"=>"Payment Verified"],
  ["id"=>"2", "monthyear"=>"Mar 2022", "refno"=>"24324-0002", "status"=>"Payment Pending"],
  ["id"=>"3", "monthyear"=>"Feb 2022", "refno"=>"24324-0001", "status"=>"Payment Verified"],
];

$payments = json_decode(apiSend('billing','get-bill-payments',[]),true);

$news = [
  ["id"=>"1", "title"=>"Fire Drill", "date"=>"21 March 2022", "img"=>"resources/images/imgNews.png"],
  ["id"=>"2", "title"=>"Building Maintenance", "date"=>"22 March 2022", "img"=>"resources/images/imgNews2.png"],
  ["id"=>"3", "title"=>"Annual General Meeting", "date"=>"23 March 2022", "img"=>"resources/images/imgNews3.png"],
];

$faqs = [
   ["title"=>"How to Book Amenity", "faq"=>"Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred labore sustainable VHS."],
   ["title"=>"How to use Quick Service Request", "faq"=>"Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred labore sustainable VHS."],
   ["title"=>"How do I pay my bill", "faq"=>"Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred labore sustainable VHS."],
];

fHeader();
?>

<!-- request form -->
<!--body style="font-size:11px"-->


	<!-- registration -->
	<div class="container">
		<div class="d-flex align-items-center justify-content-between mt-4">
			<div>
				<div class="title">Registration</div>
			</div>
			<div>
				<a href="registration.php"><i class="fas fa-arrow-right circle"></i></a>
			</div>
		</div>
		<div class="row">
			<div class="col-3 mt-3">
				<div>
					<a href="visitor.php">
						<center>
							<img class="mx-auto mb-2	" src="resources/images/icoVisitor.png" alt="" width="50" />
							<span class="btn-label font-12">Visitor</span>
						</center>
					</a>
				</div>
			</div>
			<div class="col-3 mt-3">
				<div>
					<a href="tenant.php">
						<center>
							<img class="mx-auto mb-2	" src="resources/images/icoEmployee.png" alt="" width="50" />
							<span class="btn-label">Tenant</span>
						</center>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- request forms -->
	<div class="container mt-4">
		<div class="d-flex align-items-center justify-content-between mb-1">
			<div>
				<div class="title">Forms</div>
			</div>
		</div>
		<div class="row">
			<div class="col-3 mt-3">
				<div>
					<a href="gatepass.php">
						<center>
							<img class="mx-auto mb-2" src="resources/images/icoGatePass.png" alt="" width="50" />
							<span class="btn-label">Gate Pass</span>
						</center>
					</a>
				</div>
			</div>
			<div class="col-3 mt-3">
				<div>
					<a href="servicerequest.php">
						<center>
							<img class="mx-auto mb-2" src="resources/images/icoServiceRequest.png" alt="" width="50" />
							<span class="btn-label">Service Request</span>
						</center>
					</a>
				</div>
			</div>
			<div class="col-3 mt-3">
				<div>
					<a href="reservation.php mb-2">
						<center>
							<img class="mx-auto mb-2" src="resources/images/icoReservation.png" alt="" width="50" />
							<span class="btn-label">Reservation</span>
						</center>
					</a>
				</div>
			</div>
			<div class="col-3 mt-3">
				<div>
					<a href="moveinout.php">
						<center>
							<img class="mx-auto mb-2" src="resources/images/icoMoveInOut.png" alt="" width="50" />
							<span class="btn-label" style="width:100px; margin-left:-10px">Move In / Move Out</span>
						</center>
					</a>
				</div>
			</div>
			<div class="col-3 mt-3">
				<div>
					<a href="forms.php">
						<center>
							<img class="mx-auto mb-2" src="resources/images/icoForms.png" alt="" width="50" />
							<span class="btn-label">Forms</span>
						</center>
					</a>
				</div>
			</div>
		</div>
	</div>
	<!-- recent requests -->
	<div class="container mt-5">
		<div class="d-flex align-items-center justify-content-between mb-3">
			<div>
				<div class="title">Recent Requests</div>
			</div>
			<div>
				<i class="fas fa-arrow-right circle"></i>
			</div>
		</div>
		<div id="divCarousel" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators"> 
				<?php foreach ($requests as $key=>$val) { ?> 
				<li data-target="#divCarousel" data-slide-to="<?=$key?>" class="<?=($key==0) ? "active" : ""?>"></li> 
				<?php } ?> 
			</ol>
			<div class="carousel-inner">
				<?php foreach ($requests as $key=>$val) { ?> 
				<div class="carousel-item<?=($key==0) ? " active d-block" : ""?>" style="background-color:transparent;">
					<div>
						<div class="clrBlack m-1 p-3 pb-0 bg-white rounded" style="height:auto;">
							<div class="badge badge-primary float-right badge-label"> <?=$val['status']?> </div>
							<div class="d-flex flex-column">
								<b class="font-14"> <?=$val['module']?> </b>
								<small> <?=$val['type']?> </small>
							</div>
							<div>
								<p> <?=$val['text']?> </p>
								<button type="button" class="btn btn-info btn-sm">View Details</button>
							</div>
						</div>
					</div>
				</div> 
				<?php } ?> 
			</div>
			<!-- <a class="carousel-control-prev" href="#divCarousel" role="button" data-slide="prev">
				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
				<span class="sr-only">Previous</span>
			</a>
			<a class="carousel-control-next" href="#divCarousel" role="button" data-slide="next">
				<span class="carousel-control-next-icon" aria-hidden="true"></span>
				<span class="sr-only">Next</span>
			</a> -->
		</div>
	</div>
	<!-- reservations -->
	<div class="container mt-5">
		<div class="d-flex align-items-center justify-content-between mb-3">
			<div>
				<div class="title">Reservations</div>
			</div>
			<div>
				<i class="fas fa-arrow-right circle"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-6 mt-3">
				<div>
					<img class="img-fluid" src="resources/images/imgPool.png" />
					<div class="img-label">Swimming Pool</div>
				</div>
			</div>
			<div class="col-6 mt-3">
				<div>
					<img class="img-fluid" src="resources/images/imgMassage.png" />
					<div class="img-label">Massage Room</div>
				</div>
			</div>
			<div class="col-6 mt-3">
				<div>
					<img class="img-fluid" src="resources/images/imgMeeting.png" />
					<div class="img-label">Meeting Room</div>
				</div>
			</div>
		</div>
	</div>

	<!-- recent bills payment -->
	<div class="container mt-5">
		<div class="d-flex align-items-center justify-content-between mb-4">
			<div>
				<div class="title">Recent Bills Payment</div>
			</div>
			<div>
				<i class="fas fa-arrow-right circle"></i>
			</div>
		</div> 
		
		<?php foreach($payments as $payment):?>
		<?php endforeach;?>

		<?php foreach ($bills as $key=>$val) { ?> 
		<div class="bg-white w-100 mb-2 rounded">
			<div class="d-flex align-items-center justify-content-between p-3">
				<div>
					<div class="d-flex">
						<div class="label-mthyr">
							<a href="#" class=""> <?=$val['monthyear']?> </a>
						</div>
						<div class="ml-3 subtitle"># <?=$val['refno']?> </div>
					</div>
				</div>
				<div class="badge badge-success text-white font-12 float-right"> <?=$val['status']?> </div>
			</div>
		</div> 
		<?php } ?>
	</div>
	<!-- news and announcements -->
	<div class="container mt-5">
		<div class="d-flex align-items-center justify-content-between mb-4">
			<div>
				<div class="title">News and Announcements</div>
			</div>
			<div>
				<i class="fas fa-arrow-right circle"></i>
			</div>
		</div> 
		<?php 
		foreach ($news as $key=>$val) { 
			if ($key==0) {
		?>
		<div class="card">
			<img class="card-img-top img-fluid" src="<?=$val['img']?>" alt="News">
			<div class="card-body">
				<div style="padding-left:10px; border-left:solid 5px #234E95">
					<label class="card-title news-title font-18">
						<a href="news-view.php?id=<?=$val['id']?>" class="font-weight-bold" style="text-decoration: none;"> <?=$val['title']?> </a>
					</label>
					<br>
					<label> <?=$val['date']?> </label>
				</div>
			</div>
		</div> 
		<?php 
		} else {
			if ($key==1) echo "<div class='row mt-3'>";
		?> 
		<div class="col-6 d-flex align-items-stretch">
			<div class="card">
				<img class="card-img-top" src="<?=$val['img']?>" alt="News">
				<div class="card-body p-2">
					<label class="card-title news-title">
						<a href="news-view.php?id=<?=$val['id']?>" class="font-weight-bold"> <?=$val['title']?> </a>
					</label>
					
					<label class=""> <?=$val['date']?> </label>
				</div>
			</div>
		</div> 
		<?php 
			} // if key
		} // foreach
		echo "</div>";
		?>
	</div>
	<!-- faq -->
	<div class="container mt-5">
		<div class="d-flex align-items-center justify-content-between mb-4">
			<div>
				<div class="title">Frequently ask questions</div>
			</div>
			<!-- <div>
				<i class="fas fa-arrow-right circle"></i>
			</div> -->
		</div>
		<div class="accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
			<?php foreach ($faqs as $key=>$val) { ?> 
			<div class="card my-2">
				<div class="card-header" role="tab" id="heading<?=$key?>">
					<a class="collapsed" data-toggle="collapse" data-parent="#accordionEx" href="#collapse<?=$key?>" aria-expanded="true" aria-controls="collapse<?=$key?>" style="text-decoration:none; color:#34495e;">
						<h6 class="mb-0 faq-collapse"> <?=$val['title']?> <i class="fas fa-angle-down rotate-icon" style="float:right"></i></h6>
					</a>
				</div>
				<div id="collapse<?=$key?>" class="collapse<?=($key==0) ? "show" : ""?>" role="tabpanel" aria-labelledby="heading<?=$key?>" data-parent="#accordionEx">
					<div class="card-body font-12 clrDarkblue"> <?=$val['faq']?> <?=$key?> </div>
				</div>
			</div>
			<?php } ?> 
		</div>
	</div>
	<!-- powered by -->
	<div class="" style="padding:50px 0 150px">
		<div class="row m-0 d-flex justify-content-center">
			<div class="col p-0" style="border-radius: 6px">
				<div class="col-12 d-flex align-items-center">
					<div class="mx-auto mt-auto">
						<b style="font-color:#34495E; opacity:60%">P O W E R E D&nbsp;&nbsp;&nbsp;&nbsp;B Y</b>
					</div>
				</div>
				<div class="col-12 d-flex mt-2">
					<div class="mx-auto mb-auto">
						<img class="mx-auto" src="resources/images/Inventi_Horizontal-Blue-01.png" alt="" width="100" />
					</div>
				</div>
			</div>
		</div>
	</div>
<!--/body--> 
<?=fFooter();?>