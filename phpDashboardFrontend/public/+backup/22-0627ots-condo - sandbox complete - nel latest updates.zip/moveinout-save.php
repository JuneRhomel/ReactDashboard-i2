<?php
session_start();
include("../library.php");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$post = $_POST;
if (initFile($_FILES['upload_file'])!="") // call function to init for receipt
	$post['attachments'] = initFile($_FILES['upload_file']); 
//vdump($post);

$api = apiSend('tenant','movement',$post);
//vdump($api);

/*$api = apiSend('tenant','getmoveinout',ARR_BLANK);
$api_json = json_decode($api,true);
vdump($api_json);*/

header("location: home.php");
?>