<?php
include("footerheader.php");
fHeader();
?>
<div class="col-12 my-4 d-flex align-items-center justify-content-start">
    <div class="mt-5">
        <a href="billing.php">
            <svg xmlns="http://www.w3.org/2000/svg" class="box-shadow" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="transform: scaleX(-1)">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
        </a>
    </div>
    <div class="font-18 ml-0 mt-5 ml-2"> Back to Billing Statement / SOA </div>
</div>
<div class="m-3 px-2 bg-white rounded">
    <div class="d-flex align-items-center justify-content-start py-2">
        <i class="fas fa-arrow-circle-left fa-2xl"></i> 
        <input type="text" class="form-control col-2 mx-2 text-center" value="1" width="2"> 
        <i class="fas fa-arrow-circle-right fa-2xl"></i> 
        <span class="font-14 ml-2">Page 1 of 2</span>
        <div class="d-inline-block pull-right" style="margin-left:120px;">
            <i class="fas fa-search-minus fa-2xl"></i> 
            <i class="fas fa-search-plus fa-2xl ml-2"></i> 
        </div>
    </div>
</div>
<div class="container py-2 bg-darkgray">
    <div class="d-flex align-items-center justify-content-center"><img src="resources/images/imgSOA.png"></div>
</div>
<div class="container d-inline-block mt-3" style="height:120px;">
    <div class="row">
        <div class="col-6">
            <button type="button" class="btn btn-outline btn-lg btn-block">
                <p class="mb-0 font-16">Report</p>
            </button>
        </div>
        <div class="col-6">
            <a href="billing-payment.php">
                <button type="button" class="btn btn-primary btn-lg btn-block">
                    <p class="mb-0 font-16">Pay</p>
                </button>
            </a>
        </div>
    </div>
</div>
<?php
fFooter();
?>