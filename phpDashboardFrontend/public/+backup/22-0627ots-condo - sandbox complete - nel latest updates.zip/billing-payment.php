<?php
include("footerheader.php");
fHeader();
?>
<div class="col-12 my-4 d-flex align-items-center justify-content-start">
    <div class="mt-5">
        <a href="billing.php">
            <svg xmlns="http://www.w3.org/2000/svg" class="box-shadow" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="transform: scaleX(-1)">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
        </a>
    </div>
    <div class="font-18 ml-0 mt-5 ml-2"> Back to Billing Statement / SOA </div>
</div>
<div class="mt-4 py-4" style="background-color: #fff">
    <div class="col-12">
        <div class="text-uppercase mb-2 subtitle font-18">Payment</div>
    </div>
    <div class="d-flex">
        <div class="col-2 subtitle font-16">Month:</div>
        <div class="col-10 subtitle-fade font-16">September</div>
    </div>
    <div class="d-flex">
        <div class="col-2 subtitle font-16">Type:</div>
        <div class="col-10 subtitle-fade font-16">SOA</div>
    </div>
    <div class="d-flex">
        <div class="col-2 subtitle font-16">Total:</div>
        <div class="col-10 subtitle font-16">$$$</div>
    </div>
    <div class="d-flex">
        <div class="col-2 subtitle font-16">Status:</div>
        <div class="col-10 text-danger font-16">Unpaid</div>
    </div>
</div>
<div class="mt-4 py-4" style="background-color: #fff">
    <div class="col-12">
        <div class="font-16 subtitle">Select Payment Gateway</div>
    </div>
    <div class="d-flex mt-4">
        <div class="col-4">
            <button type="button" class="btn btn-primary btn-lg py-4 px-3 w-100">
                <p class="mb-0 font-14">Paymaya</p>
            </button>
        </div>
        <div class="col-4">
            <button type="button" class="btn btn-outline btn-lg py-4 px-3 w-100">
                <p class="mb-0 font-14">Gcash</p>
            </button>
        </div>
        <div class="col-4">
            <button type="button" class="btn btn-outline btn-lg py-4 px-3 w-100">
                <p class="mb-0 font-14">Coins.ph</p>
            </button>
        </div>
    </div>
    <hr />
    <div class="col-12 mb-2">
        <div class="mb-2 font-16 subtitle">Unit Number</div>
        <input type="email" class="form-control" id="exampleInputEmail1" />
    </div>
    <div class="col-12 mb-2">
        <div class="mb-2 font-16 subtitle">Account Number</div>
        <input type="email" class="form-control" id="exampleInputEmail1" />
    </div>
    <div class="col-12 mb-2">
        <div class="mb-2 font-16 subtitle">SOA Total</div>
        <input type="email" class="form-control" readonly value="$$$" id="exampleInputEmail1" />
    </div>
    <div class="col-12 mb-2">
        <div class="mb-2 font-16 subtitle">Mobile Number</div>
        <input type="email" class="form-control" id="exampleInputEmail1" />
    </div>
    <div class="col-12 mt-4">
        <div class="d-flex justify-content-between">
            <div class="font-16 subtitle">Sent Receipt to Email</div>
            <div>
                <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="customSwitch1" />
                    <label class="custom-control-label" for="customSwitch1"></label>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 mt-4">
        <button type="button" class="btn btn-primary btn-lg btn-block mb-5">
            <p class="mb-0">Pay Now</p>
        </button>
    </div>
</div>
<?php
fFooter();
?>