<?php
include("footerheader.php");

$news_result = apiSend('news','getlist',[]);
$news = json_decode($news_result,true);

fHeader();
?>
<div class="col-12 my-4 d-flex align-items-center justify-content-between">
	<div class="title"> News and Announcement </div>
</div>
<div class="container">
  <div class="card">
	<img class="card-img-top" src="resources/images/imgNews.png" alt="News">
	<div class="card-body">
	  <div style="padding-left:10px; border-left:solid 5px #234E95">
		<label class="card-title font-18"><b>Fire Drill</b></label><br>
		<label><i class="fa fa-calendar" aria-hidden="true"></i> 25 March 2022</label>

	  </div>
	  <p class="mt-2 font-14">
		  A ranking official of the Bureau of Fire Protection (BFP) on Tuesday said firefighters will continue to engage the community to make the residents feel safe and secure from fires and any forms of man-made and natural calamities.          
		  <br>
		  <a href="news-view.php"><u>Read More</u></a>
	  </p>
	</div>
  </div>
</div>
<div class="col-12 my-4 d-flex align-items-center">
	<div class="title font-18"> MORE NEWS </div>
</div>

<?php foreach($news as $n):?>
<div class="container mb-3" style="margin-bottom:0px">
	<div class="card">
		<div class="card-body">
		<div class="d-inline-block mt-0">
			<small> <?php echo date('d M Y',$n['created_on']);?></small><br>
			<b><?php echo $n['title'];?></b></u></a></label><br>
			<p><?php echo nl2br($n['content']);?></p>
			<a href="news-view.php"><u>Read More</u></a>
		</div>

		</div>
	</div>
</div>
<?php endforeach;?>

<!--div class="container mb-3" style="margin-bottom:0px">
  <div class="card">
	<div class="card-body">
	  <div class="d-inline-block mt-0">
		<small> 25 March 2022</small><br>
		<b>Building Maintenance</b></u></a></label><br>
		<p>In his speech, chief Supt. Felixberto Abrenica, BFP director for operations...</p>
		<a href="news-view.php"><u>Read More</u></a>
	  </div>

	</div>
  </div>
</div>
<div class="container mb-3" style="margin-bottom:0px">
  <div class="card">
	<div class="card-body">
	  <div class="d-inline-block mt-0">
		<small> 25 March 2022</small><br>
		<b>Building Maintenance</b></u></a></label><br>
		<p>In his speech, chief Supt. Felixberto Abrenica, BFP director for operations...</p>
		<a href="#"><u>Read More</u></a>
	  </div>

	</div>
  </div>
</div>
<div class="container" style="margin-bottom:100px">
  <div class="card">
	<div class="card-body">
	  <div class="d-inline-block mt-0">
		<small> 25 March 2022</small><br>
		<b>Building Maintenance</b></u></a></label><br>
		<p>In his speech, chief Supt. Felixberto Abrenica, BFP director for operations...</p>
		<a href="#"><u>Read More</u></a>
	  </div>

	</div>
  </div>
</div-->
<?php
fFooter();
?>