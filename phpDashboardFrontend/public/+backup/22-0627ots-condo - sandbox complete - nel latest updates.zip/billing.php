<?php
include("footerheader.php");
$billings_result = apiSend('billing','getlist',[]);
$billings = json_decode($billings_result,true);

fHeader();
?>
<div class="col-12 d-flex align-items-center justify-content-between mt-4 mb-5">
	<div class="title">Billing Statement / SOA</div>
	<!--div>
		<a href="selectrequest.html">
			<button class="btn btn-primary px-3 w-100">New</button>
		</a>
	</div-->
</div>
<?php foreach($billings as $billing):?>
<div class="bg-white">
	<div class="col-12 mb-3 py-3">
		
			<div class="mt-2">
				

				<div class="row">
					<div class="col-2 font-14 start subtitle">Month:</div>
					<div class="col-10 font-14 subtitle-fade"><?php echo date('F',strtotime($billing['billing_date']));?></div>
				</div>
				<div class="row">
					<div class="col-2 font-14 subtitle">Type:</div>
					<div class="col-10 font-14 subtitle-fade"><?php echo $billing['billing_type'];?></div>
				</div>
				<div class="row">
					<div class="col-2 font-14 subtitle">Total:</div>
					<div class="col-10 font-14 subtitle"><?php echo number_format($billing['amount'],2);?></div>
				</div>
				<div class="row">
					<div class="col-2 font-14 subtitle">Status:</div>
					<div class="col-10 subtitle font-14 text-<?php echo ($billing['amount'] == $billing['payment'] ? 'success' : 'danger');?>"><?php echo ($billing['amount'] == $billing['payment'] ? 'Paid' : 'Unpaid');?></div>
				</div>
			</div>
			<div class="d-flex mt-4">
				<div>
					<a href="billing-view.php">
						<button class="btn btn-outline px-5 w-100 text-uppercase"> View </button>
					</a>
				</div>
				<div>
					<button class="btn btn-primary px-5 w-100 ml-2 text-uppercase" onclick="location='billing-payment.php'"> Pay </button>
				</div>
			</div>
	</div>
</div>
<?php endforeach;?>


<?php
fFooter();
?>