<?php
include("footerheader.php");
fHeader();
?>
<div class="container">
<div class=" d-flex align-items-center justify-content-start mt-5 mb-4">
  <div>
      <a href="news.php">
          <svg xmlns="http://www.w3.org/2000/svg" class="box-shadow" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" style="transform: scaleX(-1)">
              <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
      </a>
  </div>
  <div class="font-14 ml-2"> Back to News & Announcements </div>
</div>
</div>
<div class="container">
    <img class="card-img-top rounded" src="resources/images/imgNews.png" alt="News">
    <div class="mt-2">
      <div>
        <label class="card-title font-18"><b>Fire Drill</b></label><br>
        <label><i class="fa fa-calendar" aria-hidden="true"></i> 25 March 2022</label>
      </div>
      <p class="mt-2 font-14">
        A ranking official of the Bureau of Fire Protection (BFP) on Tuesday said firefighters will continue to engage the community to make the residents feel safe and secure from fires and any forms of man-made and natural calamities.
      </p>
      <p class="mt-2 font-14">
        In his speech, chief Supt. Felixberto Abrenica, BFP director for operations, said bureau personnel should be visible to the public even beyond March of each year when the entire country is celebrating Fire Prevention Month.
      </p>
    </div>
</div>
<?php
fFooter();
?>