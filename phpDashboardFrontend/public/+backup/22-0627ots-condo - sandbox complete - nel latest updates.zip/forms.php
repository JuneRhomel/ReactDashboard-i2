<?php
include("footerheader.php");
$form_result = apiSend('form','getlist',[]);
$forms = json_decode($form_result,true);
fHeader();
?>
<div class="col-12 my-4 d-flex align-items-center justify-content-between">
	<div class="title mt-5"> Forms </div>
</div>
<div>
  <ul>
	<li>Download form</li>
	<li>Upload form anytime</li>
	<li>Better experience in Web/Desktop view</li>
  </ul>
</div>
<div class="col-12 mb-4">
	<nav>
		<div class="nav nav-tabs" id="nav-tab" role="tablist" style="border-bottom:solid 1px transparent">
			<button class="nav-link <?=($type=="") ? "active" : ""?>" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>'"> Forms </button>
			<button class="nav-link <?=($type!="") ? "active" : ""?>" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>?type=tenant'"> Uploaded Form </button>
		</div>
	</nav>
</div>

<div class="container" style="margin-bottom: 0px">
	<div class="accordion" id="accordionEx" role="tablist" aria-multiselectable="true">
		<?php foreach($forms as $form):?>
		<div class="card my-1">
			<div class="card-header" role="tab" id="heading1" style="padding: 0 0 0 60px; height:60px; background-image: url(resources/images/icoPDF.png); background-repeat:no-repeat">
				<a href="form-view.php?formid=<?php echo $form['id'];?>" style="text-decoration: none; color:#34495e">
					<h6><i class="fas fa-download box-shadow" style="margin: 15px 20px 0 0; float:right"></i></h6>
					<div>
						<span class="font-16"><?php echo $form['title'];?></span><br><small>Update last <?php echo date('d-F-Y',$form['created_on']);?></small>
					</div>
				</a>
			</div>
		</div>
		<?php endforeach;?>

		<!--div class="card my-1">
		<div class="card-header" role="tab" id="heading1" style="padding: 0 0 0 60px; height:60px; background-image: url(resources/images/icoWord.png); background-repeat:no-repeat">
			<a href="docs-view.php" style="text-decoration: none; color:#34495e">
				<h6><i class="fas fa-download box-shadow" style="margin: 15px 20px 0 0; float:right"></i></h6>
				<div>
					<span class="font-16">Car Sticker Application</span><br><small>Update last 25-May-2022</small>
				</div>
			</a>
		</div>
		</div>
		<div class="card my-1">
		<div class="card-header" role="tab" id="heading2" style="padding: 0 0 0 60px; height:60px; background-image: url(resources/images/icoPDF.png); background-repeat:no-repeat">
			<a href="docs-view.php" style="text-decoration: none; color:#34495e">
				<h6><i class="fas fa-download box-shadow" style="margin: 15px 20px 0 0; float:right"></i></h6>
				<div>
					<span class="font-16">Master Deed of Restrictions</span><br><small>Update last 25-May-2022</small>
				</div>
			</a>
		</div>
		</div>
		<div class="card my-1">
		<div class="card-header" role="tab" id="heading1" style="padding: 0 0 0 60px; height:60px; background-image: url(resources/images/icoWord.png); background-repeat:no-repeat">
			<a href="docs-view.php" aria-expanded="true" style="text-decoration: none; color:#34495e">
				<h6><i class="fas fa-download box-shadow" style="margin: 15px 20px 0 0; float:right"></i></h6>
				<div>
					<span class="font-16">Car Sticker Application</span><br><small>Update last 25-May-2022</small>
				</div>
			</a>
		</div>
		</div>
		<div class="card my-1">
		<div class="card-header" role="tab" id="heading2" style="padding: 0 0 0 60px; height:60px; background-image: url(resources/images/icoPDF.png); background-repeat:no-repeat">
			<a href="docs-view.php" style="text-decoration: none; color:#34495e">
				<h6><i class="fas fa-download box-shadow" style="margin: 15px 20px 0 0; float:right"></i></h6>
				<div>
					<span class="font-16">Master Deed of Restrictions</span><br><small>Update last 25-May-2022</small>
				</div>
			</a>
		</div>
		</div-->
		</div>
	</div>
<?php
fFooter();
?>