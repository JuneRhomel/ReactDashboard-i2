<?php
include("footerheader.php");
fHeader();
?>
<div class="col-12 my-4 d-flex align-items-center justify-content-between">
    <div class="title mt-5"> Directory </div>
</div>
<div class="container my-5">
  <div class="card">
    <div class="card-body">
      <div class="d-block mt-0 pb-0">
        <img src="resources/images/user-female.jpg" class="user-image" alt="User Image"/><br>
        <span class="fa-stack fa-1x float-right">
          <i class="fa-solid fa-circle fa-stack-1x" style="background:#234E95; border-radius:50%"></i>
          <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
        </span>
        <b class="font-16 mt-2">Celia Fahey</b><br>
        <label class="font-12 mt-0">OPERATIONS MANAGER</label><br>
        <label class="mt-1">operations@inventi.ph</label>
      </div>
    </div>
  </div>
</div>
<div class="container my-5">
  <div class="card">
    <div class="card-body">
      <div class="d-block mt-0 pb-0">
        <img src="resources/images/user-male.jpg" class="user-image" alt="User Image"/><br>
        <span class="fa-stack fa-1x float-right">
          <i class="fa-solid fa-circle fa-stack-1x" style="background:#234E95; border-radius:50%"></i>
          <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
        </span>
        <b class="font-16 mt-2">Jaylin Pfannerstill</b><br>
        <label class="font-12 mt-0">BUILDING MANAGER</label><br>
        <label class="mt-1">building@inventi.ph</label>
      </div>
    </div>
  </div>
</div>
<div class="container my-5">
  <div class="card">
    <div class="card-body">
      <div class="d-block mt-0 pb-0">
        <img src="resources/images/user-female.jpg" class="user-image" alt="User Image"/><br>
        <span class="fa-stack fa-1x float-right">
          <i class="fa-solid fa-circle fa-stack-1x" style="background:#234E95; border-radius:50%"></i>
          <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
        </span>
        <b class="font-16 mt-2">Celia Fahey</b><br>
        <label class="font-12 mt-0">OPERATIONS MANAGER</label><br>
        <label class="mt-1">operations@inventi.ph</label>
      </div>
    </div>
  </div>
</div>
<div class="container my-5">
  <div class="card">
    <div class="card-body">
      <div class="d-block mt-0 pb-0">
        <img src="resources/images/user-male.jpg" class="user-image" alt="User Image"/><br>
        <span class="fa-stack fa-1x float-right">
          <i class="fa-solid fa-circle fa-stack-1x" style="background:#234E95; border-radius:50%"></i>
          <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
        </span>
        <b class="font-16 mt-2">Jaylin Pfannerstill</b><br>
        <label class="font-12 mt-0">BUILDING MANAGER</label><br>
        <label class="mt-1">building@inventi.ph</label>
      </div>
    </div>
  </div>
</div>
<?php
fFooter();
?>