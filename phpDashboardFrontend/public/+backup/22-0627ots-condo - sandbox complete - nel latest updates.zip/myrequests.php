<?php
include("footerheader.php");

$servicerequest_result = apiSend('servicerequest','getlist',[]);
$servicerequests = json_decode($servicerequest_result,true);

fHeader();
global $scriptname;

$requests = [
  ["id"=>"1", "module"=>"GATE PASS", "type"=>"Delivery", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", 
    "date"=>"30 June 2022", "user"=>"Food Panda", "location"=>"", "status"=>"New"],
  ["id"=>"2", "module"=>"SERVICE REQUEST", "type"=>"Maintenance", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", 
    "date"=>"", "user"=>"", "location"=>"Location1", "status"=>"In Progress"],
  ["id"=>"3", "module"=>"RESERVATION", "type"=>"Swimming Pool", "text"=>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua", 
    "date"=>"1 July 2022", "user"=>"", "location"=>"Pool 1","status"=>"Closed"],
];

$status = initObj('status');
?>
<div class="col-12 d-flex align-items-center justify-content-between mt-4 mb-5">
    <div class="title">My Requests</div>
    <div>
        <a href="selectrequest.html">
            <button class="btn btn-primary btn-lg pb-0"><h6>New</h6></button>
        </a>
    </div>
</div>
<div class="col-12 mb-4">
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist" style="border-bottom:solid 1px transparent">
            <button class="nav-link <?=($status=="") ? "active" : ""?>" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>'"> In Progress </button>
            <button class="nav-link <?=($status!="") ? "active" : ""?>" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false" style="border-bottom:solid 2px var(--clrBlue);" onclick="location='<?=$scriptname?>?status=ALL'"> All Requests </button>
        </div>
    </nav>
</div>
<?php 
foreach ($requests as $key=>$val) { 
    if ($status=="ALL") {
?> 
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['module']?></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="label-fade"><?=$val['type']?></div>
            </div>
        </div>
        <div>
            <div><?=$val['text']?></div>
            <?php if ($val['date']!="") { ?>
            <div class="d-flex mt-3 align-items-center">
                <div><i class="fa fa-calendar icon-inverse"></i></div>
                <div class="ml-2"><?=$val['date']?></div>
            </div>
            <?php } ?>
            <?php if ($val['user']!="") { ?>
            <div class="d-flex mt-2 align-items-center">
                <div><i class="fa fa-user icon-inverse"></i></div>
                <div class="ml-2"><?=$val['user']?></div>
            </div>
            <?php } ?>
            <?php if ($val['location']!="") { ?>
            <div class="d-flex mt-2 align-items-center">
                <div><i class="fa fa-map-marker-alt icon-inverse"></i></div>
                <div class="ml-2"><?=$val['location']?></div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php 
    } else { 
        if ($val['status']=="In Progress") {
?>
<div class="bg-white">
    <div class="col-12 mb-3 py-3">
        <div class="">
            <div class="d-flex align-items-center justify-content-between">
                <div class="font-16 font-weight-bold"><?=$val['module']?></div>
                <div class="badge badge-primary pull-right badge-label w-25 pt-2 pb-0"><h6><?=$val['status']?></h6></div>
            </div>
        </div>
        <div class="mb-2">
            <div class="d-flex align-items-center justify-content-between">
                <div class="label-fade"><?=$val['type']?></div>
            </div>
        </div>
        <div>
            <div><?=$val['text']?></div>
            <?php if ($val['date']!="") { ?>
            <div class="d-flex mt-3 align-items-center">
                <div><i class="fa fa-calendar icon-inverse"></i></div>
                <div class="ml-2"><?=$val['date']?></div>
            </div>
            <?php } ?>
            <?php if ($val['user']!="") { ?>
            <div class="d-flex mt-2 align-items-center">
                <div><i class="fa fa-user icon-inverse"></i></div>
                <div class="ml-2"><?=$val['user']?></div>
            </div>
            <?php } ?>
            <?php if ($val['location']!="") { ?>
            <div class="d-flex mt-2 align-items-center">
                <div><i class="fa fa-map-marker-alt icon-inverse"></i></div>
                <div class="ml-2"><?=$val['location']?></div>
            </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php 
        } // if status=in progress
    } // if status
} // foreach
?>
<div class="mt-5">&nbsp;</div>
<?=fFooter();?>