<?php
session_start();
include('../library.php');
function fHeader() {
  global $rootpath;

  $locinfo = getLocInfo();
  $unit = $locinfo['location_name'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Inventi Condo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous" />
    <link rel="stylesheet" href="custom.css?v=<?=time()?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  </head>
  <body>
    <!-- header -->
    <nav class="top-nav py-3 fixed-top" style="background-color:#fefefe;">
      <div class="container">
        <div class="d-flex align-items-center justify-content-between" style="height: 50px;">
          <div class="d-flex align-items-center">
            <div>
              <svg type="button" data-toggle="modal" data-target="#sidemenu" style="width: 20px; color: #234e95" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" class="mr-2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4 8h16M4 16h16" />
              </svg>
            </div>
            <div>
                <a href="<?=$root?>">
                  <img class="mx-auto" src="resources/images/Inventi_Horizontal-Blue-01.png" alt="" width="100" />
                </a>
            </div>
          </div>
          <div>
            <i class="fa fa-bell circle"></i>
            <img class="ml-3" style="border-right: 2px solid #dfdfdf; height: 30px;"></img>
            <label class="mx-2 pl-2 font-12 clrDarkBlue"><?=$unit?>Unit Name</label>
            <i class="fa fa-user circle"></i>
          </div>
        </div>
      </div>
    </nav>
    <!-- sidemenu modal -->
    <div class="modal" id="sidemenu" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
      <div class="modal-dialog m-0 w-75" role="document" style="width: 100%; height: 100%">
        <div class="modal-content" style="height: auto; min-height: 100%; border-radius: 0">
          <!-- <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <img src="https://dummyimage.com/640x400/fff/aaa" alt="" class="img-fluid position-relative" />
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div> -->
          <div class="modal-body font-14">
            <div class="font-16 mb-1">My Profile</div>
            <div class="font-16 mb-1">Feedbacks</div>
            <div class="font-16 mb-1">Online Forms</div>
            <div class="font-16 mb-1">Settings</div>
            <div class="font-16 mb-1">Directory</div>
            <div class="font-16 mb-1">Terms and Condition</div>
            <div class="font-16 mb-1">FAQs</div>
            <hr />
            <div class="font-18"><a href="logout.php">Logout</a></div>
            <hr />
          </div>
          <div class="modal-footer">
            <div class="text-center font-14">Help us get better with your feedback</div>
            <button class="mx-auto">Take Survey</button>
            <!-- <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              Close
            </button><button type="button" class="btn btn-primary">Save changes</button> -->
          </div>
        </div>
      </div>
    </div>
<?php 
} // end of fHeader

function fFooter() {
?>
    <!-- bottom tabs -->
    <div class="mt-5"></div>
    <div class="fixed-bottom bg-white">
      <div class="row m-0 d-flex align-items-center justify-content-between" style="height: 70px;">
        <a href="dashboard.php" class="active">
          <div class="col p-0" style="border-radius: 6px">
            <div class="col-12 d-flex align-items-center">
              <div class="mx-auto mt-auto">
                <a href="home.php">
                  <svg xmlns="http://www.w3.org/2000/svg" style="width: 20px" class="mt-2 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                </a>
              </div>
            </div>
            <div class="col-12 d-flex">
              <div class="mx-auto mb-auto">
                  <div class="mb-1 font-9">Home</div>                
              </div>
            </div>
          </div>
        </a>
        <a href="myrequests.php" class="">
          <div class="col p-0" style="border-radius: 6px">
            <div class="col-12 d-flex align-items-center">
              <div class="mx-auto mt-auto">
                <svg xmlns="http://www.w3.org/2000/svg" class="mt-2 mb-1" style="width: 20px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                  <path stroke-linecap="round" stroke-linejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                </svg>
              </div>
            </div>
            <div class="col-12 d-flex">
              <div class="mx-auto mb-auto">
                <div class="mb-1 font-9">My Requests</div>
              </div>
            </div>
          </div>
        </a>
        <div class="col p-0 menu">
          <a href="billing.php" class="">
            <div class="col p-0" style="border-radius: 6px">
              <div class="col-12 d-flex align-items-center">
                <div class="mx-auto mt-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" class="mt-2 mb-1" style="width: 20px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                  </svg>
                </div>
              </div>
              <div class="col-12 d-flex">
                <div class="mx-auto mb-auto">
                  <div class="mb-1 font-9">Billing</div>
                </div>
              </div>
            </div>
          </a>
        </div>
        <div class="col p-0 menu" style="border-radius: 6px">
          <a href="docs.php" class="">
            <div class="col p-0" style="border-radius: 6px">
              <div class="col-12 d-flex align-items-center">
                <div class="mx-auto mt-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" class="mt-2 mb-1" style="width: 20px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
              </div>
              <div class="col-12 d-flex p-0">
                <div class="mx-auto mb-auto">
                  <div class="mb-1 font-9 text-center" >House Rules</div>
                </div>
              </div>
            </div>
          </a>
        </div>
        <div class="col p-0 menu" style="border-radius: 6px">
          <a href="news.php" class="">
            <div class="col p-0" style="border-radius: 6px">
              <div class="col-12 d-flex align-items-center">
                <div class="mx-auto mt-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" class="mt-2 mb-1" style="width: 20px" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                  </svg>
                </div>
              </div>
              <div class="col-12 d-flex">
                <div class="mx-auto mb-auto">
                  <div class="mb-1 font-9">Announcement</div>
                </div>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
    <div class="bg-white fixed-bottom">
<div>

</div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  </body>
</html>
<?php
  if ($tenant=="") {
    //echo "<script>swal('Information','Session expired, please login again'); location='/';</script>";
  }
} // end of fFooter
?>